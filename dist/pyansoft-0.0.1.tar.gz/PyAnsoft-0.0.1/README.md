# PyAnsoft

Python interaction with ANSYS Electronic Desktop 2016-2017.
