import os
import sys
sys.path.append('../pyansoft')
# sys.path.append(fpath)
print(sys.path)
import pyansoft